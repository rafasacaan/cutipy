def say_your_name(name):
    return f"Hi, {name}. Welcome to cutipy."